
This demo shows how to use resources to create a client side validator tag, and use it
within a page.
This demo, the basic-ajax demo, is a collection of small example programs that have
been placed into a demo framework.

The best way to understand the demo is to simply run it - there are links in the
home page to each example, as well as the code backing each example.

The following examples are part of this demo:

count - simple example of using Ajax to update a field in the page
echo1 - simple example of using Ajax to update a field, with external JavaScript
echo2 - using an ajax tag to do the same thing as echo1
hidenshow - how to handle rendered=false
redirect - using Ajax to redirect to a new page
listener - using event and listener on an f:ajax tag

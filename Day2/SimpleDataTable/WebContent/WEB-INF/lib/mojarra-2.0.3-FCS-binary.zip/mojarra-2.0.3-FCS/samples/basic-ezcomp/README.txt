This demo, the basic-ezcomp demo, is a collection of small example programs that have
been placed into a demo framework.

The best way to understand the demo is to simply run it - there are links in the
home page to each example, as well as the code backing each example.

The following examples are part of this demo:

out - create a simple component that outputs text with a yellow background
inout - a simple component that accepts input
contract - using a bean as an attribute value
spinner - basic spinner component
spinnerStyled - adding styling to the spinner component
spinnerFinal - making the spinner work if you use it multiple times in a page
nav - component that navigates to a new page
actionListener - component that takes an f:actionListener child

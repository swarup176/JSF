This demo, the custom-bean-scope demo, demonstrates the use of custom
'managed-bean-scope'.

The easiest way to understand the demo is to deploy
and run it, and then review the source code, particularly, the
CustomScopeELResolver.

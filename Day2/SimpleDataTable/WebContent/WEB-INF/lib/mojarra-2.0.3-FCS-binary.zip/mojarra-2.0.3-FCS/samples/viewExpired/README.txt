This demo contains a simple example of gracefully handling a view expired exception.

See the viewExpired.xhtml page for a link to a blog discussing the concepts in this demo.